from django.urls import path
from . import views


urlpatterns = [
    path('', views.index),
    path('run_function/', views.run_function),
    path('dostup/', views.dostup),
    path('registration/', views.registration),
    path('main/', views.main),
    path('upload/', views.upload_file, name='upload_file'),
    #path('report/', views.report),
]
