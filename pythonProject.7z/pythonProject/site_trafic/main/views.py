from django.shortcuts import render
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt

import psycopg2
import pandas as pd

from django.shortcuts import redirect

def index(request):
    return render(request, 'main/index.html')

def main(request):
    return render(request, 'main/main.html')

@csrf_exempt
def run_function(request):
    # print('123')
    response_data = 'successful!'
    login = request.POST.get('login')
    password = request.POST.get('password')
    print('123-321 ' + str(login)+' '+str(password))

    conn = psycopg2.connect(database="auth_user",
                            host="localhost",
                            user="Admin",
                            password="rotokan123",
                            port="7777")
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM auth_user "
                   "where login='"+str(login)+"' and password='"+str(password)+"'")

    all_users = cursor.fetchall()
    if len(all_users)==0:
        cursor.close()
        conn.close()
        return HttpResponse("Неверная пара логин\пароль")

    cursor.close()
    conn.close()
    return render(request, 'main/main.html')

def dostup(request):
    return render(request, 'main/dostup.html')

def registration(request):
    login = request.POST.get('login')
    password = request.POST.get('password')
    email = request.POST.get('email')

    conn = psycopg2.connect(database="auth_user",
                            host="localhost",
                            user="Admin",
                            password="rotokan123",
                            port="7777")
    conn.autocommit = True
    cursor = conn.cursor()
    cursor.execute('insert into auth_user values (default,\''+str(login)+'\',\''+str(password)+'\',\''+str(email)+'\')')
    cursor.close()
    conn.close()
    return HttpResponse("Регистрация завершена")

def upload_file(request):
    if request.method == 'POST':
        df = request.FILES['excel_file']
        # обработка файла здесь
    else:
        return HttpResponse("Error")
    df = pd.read_excel(df)
    df.drop(df.columns[[0, 3, 7, 8, 9, 10, 11, 12, 13, 14, 15]], axis=1, inplace=True)

    df[['X', 'Y']] = df.coord.str.split(",", expand=True)
    # df.drop(df.columns[[1]], axis= 1 , inplace= True )
    df['X'] = df['X'].map(lambda x: x.lstrip('[').rstrip('[')).astype(float)
    df['Y'] = df['Y'].map(lambda x: x.lstrip(']').rstrip(']')).astype(float)

    df.X = df.X.round().astype(int)
    df.Y = df.Y.round().astype(int)

    min_X = df['X'].min()
    min_Y = df['Y'].min()

    df.loc[:, "X"] = df["X"].apply(lambda x: x - min_X)
    df.loc[:, "Y"] = df["Y"].apply(lambda x: x - min_Y)
    df['X'].round()
    df['Y'].round()

    edges = pd.DataFrame(data=df['edge'].unique())

    df1 = df[(df.spd == 0)]
    f1 = df[(df.spd == 0)]
    data = []
    for index, Edge in edges.iterrows():
        df2 = df1[(df1.edge == Edge[0])]
        data.append(df2.shape[0])
    edges['kolvo'] = data

    from PIL import Image, ImageDraw

    dfX = pd.DataFrame(data=df['X'].unique())
    dfY = pd.DataFrame(data=df['Y'].unique())

    X = int(dfX.max() * 1.1)
    Y = int(dfY.max() * 1.1)

    img = Image.new(mode="RGB", size=(X, Y), color=(255, 255, 255))
    pixels = img.load()
    X, Y = img.size

    draw = ImageDraw.Draw(img)

    for index, row in df.iterrows():
        X = row['X']
        Y = row['Y']
        R = 10

        draw.ellipse((X - R, Y - R, X + R, Y + R), fill=(0, 0, 0, 0), width=R)

    dfSPD0 = df[(df.spd < 3)]
    for index, row in dfSPD0.iterrows():
        X = row['X']
        Y = row['Y']
        R = 30
        draw.ellipse((X - R, Y - R, X + R, Y + R), fill=('#ff0000'), width=R)
    img.show()

    edges = edges.sort_values(by=['kolvo'], ascending=[False])
    #return HttpResponse(df.to_html(edges))

    html_table = edges.to_html()

    context = {
        'html_table': html_table,
    }
    return render(request, 'main/report.html', context)
